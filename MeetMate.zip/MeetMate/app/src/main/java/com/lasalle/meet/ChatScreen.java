package com.lasalle.meet;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ChatScreen extends AppCompatActivity {

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.chat_acticity);
        }
}
